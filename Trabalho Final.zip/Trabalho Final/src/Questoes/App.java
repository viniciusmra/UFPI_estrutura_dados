package Questoes;

import java.io.FileNotFoundException;
import java.util.Vector;
import java.util.Scanner;

public class App <Key, Value>{

    public static void main(String[] args) throws FileNotFoundException {

		//Vector<String> arq = new Vector<String>();
		//criando arquivo sem palavras repetidas
		//arq = readWords("leipzig100kUnic.txt");
        // arq = readWords("src/Questoes/leipzig100k.txt");
		// newFile(arq, "src/Questoes/leipzig100kUnic.txt");
		// boolean flag = true;
		// while(flag){

		// 	System.out.println("=-=-=-=-=-=-=");
		// 	System.out.println("     MENU    ");
		// 	System.out.println("=-=-=-=-=-=-=");
		// 	System.out.println("1 - CLASSES LIST");
		// 	System.out.println("2 - CLASSES SET");
		// 	System.out.println("3 - CLASSES MAP");
		// 	System.out.println("4 - TUDO");
		// 	System.out.println("5 - SAIR");


		// 	switch(){

		// 		case 1:
		// 		break;

		// 		case 2:
		// 		break;

		// 		case 3:
		// 		break;

		// 		case 4:
		// 		break;

		// 		case 5:
		// 		break;

		// 		default:

		// 	}
		// }
		
		
		
		//QUESTAO 1:
		Questao1 classeQ1 = new Questao1();
		Vector<String> metodosQ1 = new Vector<String>();
		//String filename = "leipzig100kUnic.txt";
		
		// aq1Vect.addAll(q1.timeST("leipzig100kUnic.txt"));

		// for(int i=0; i< aq1Vect.size(); i++){
		// 	System.out.println(aq1Vect.get(i));
		// }



		metodosQ1.addAll(classeQ1.timeVectorST("Trabalho Final/src/Questoes/leipzig100kUnic.txt"));
		metodosQ1.addAll(classeQ1.timeArrayListST("Trabalho Final/src/Questoes/leipzig100kUnic.txt"));
		metodosQ1.addAll(classeQ1.timeLinkedListST("Trabalho Final/src/Questoes/leipzig100kUnic.txt"));

		for(int i=0; i<  metodosQ1.size(); i++){
			System.out.println(metodosQ1.get(i));
		}

		// //QUESTAO 2:

		// Questao2 q2 = new Questao2();
		// Vector<String> aq2Vect = new Vector<String>();
		// aq2Vect.addAll(q2.ST("leipzig100kUnic.txt"));

		// for(int j=0; j< aq2Vect.size(); j++){
		// 	System.out.println(aq2Vect.get(j));
		// }

		//QUESTAO 3:

		// Questao3 q3 = new Questao3();
		// Vector<String> aq3Vect = new Vector<String>();
		// aq3Vect.addAll(q3.ST("leipzig100kUnic.txt"));

		// for(int j=0; j< aq3Vect.size(); j++){
		// 	System.out.println(aq3Vect.get(j));
		// }

		
		
     }

}